import logo from './logo.svg';
import './App.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faMapMarkerAlt } from '@fortawesome/free-solid-svg-icons'
import { faCartShopping , faBars } from '@fortawesome/free-solid-svg-icons'

import React, { Component } from 'react'
import PropTypes from 'prop-types'

/**
* @author
* @class App
**/
//we are using class component
class App extends Component {
  //properties
  state = {}
  //constructor




  //method
  render() {

    return (
      <div>
        <header>
          <div className="a_top_header p-1 ">

            <button className='me-1 btn  h-100 ' style={{ 'width': '10%' }}>
              <img className='img-fluid' src="./images/sliders/logo.jpg" alt="lodp" />
            </button>

            <button className='lh-1 text-white fs-6 me-1 btn h-100' style={{ 'width': '10%' }} >
              delivery to monu
              <FontAwesomeIcon icon={faMapMarkerAlt} />
              <span className='fw-bold d-block'><span className='a_city'>NewYork</span><span className='a_pincode' >1234</span></span>
            </button>
            <form className=' bg-white hform w-50 h-75 d-inline-block' >SEARCH</form>
            <button className=' btn btn-info h-100' style={{ 'width': '4%' }}  >C</button>
            <button className=' btn btn-info h-100' style={{ 'width': '8%' }} >D</button>
            <button className=' btn btn-info h-100' style={{ 'width': '8%' }}>E</button>
            <button className=' btn text-white fs-4 h-100' style={{ 'width': '8%' }}>
              <FontAwesomeIcon icon={faCartShopping} />cart
            </button>
          </div>
     <div className="a_bottom_header">

     <nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"><FontAwesomeIcon icon={faBars} />   All</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link"  href="#">Sell</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Best seller</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Mobile</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="#">Electronics</a>
        </li>
        
        <li class="nav-item">
          <a class="nav-link" href="#">Home & Kitchen</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="#">Customer service</a>
        </li>
        
        <li class="nav-item">
          <a class="nav-link" href="#">Fashnion</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Amazon Pay</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="#">Computers</a>
        </li>
        
        <li class="nav-item">
          <a class="nav-link" href="#">Today Deals</a>
        </li>
        
        <li class="nav-item">
          <a class="nav-link" href="#">Prime</a>
        </li>
        
        
        
        
      </ul>
    </div>
  </div>
</nav>





     </div>

      </header>

        <main className="a_main  position-relative">
          <div className="a_main1 a_main_top ">

            <div id="carouselExample" className="carousel slide  ">
              <div className="carousel-inner">
                <div className="carousel-item active">
                  <img src="./images/sliders/1.jpg" className="d-block " alt="phone" />
                </div>

                <div className="carousel-iteam">
                  <img src="./images/sliders/2.jpg" className="d-block " alt="slider" />

                </div>
                <div className="carousel-item">
                  <img src="./images/sliders/3.jpg" className="d-block " alt="loading" />
                </div>
              </div>

              <button className="carousel-control-next h-50 " type="button" data-bs-target="#carouselExample" data-bs-slide="next">
                <span className="carousel-control-next-icon" aria-hidden="true"></span>
                <span className="visually-hidden">Next</span>
              </button>
            </div>
          </div>

          <div className=" ml-1 position-absolute a_main_bottom ">
            <div className="a_main_bottom_1 row m-0  mb-3 ">
              <div className="col">A</div>
              <div className="col">B</div>
              <div className="col">C</div>
              <div className="col">D</div>

            </div>

            <div className="a_main_bottom_2 row m-0 mb-3 ">

              <div className="col-6 ">A</div>
              <div className="col-3 ">B</div>
              <div className="col-3">C</div>



            </div>

            <div className="a_main_bottom_3">

              <div className="TODAYDEAL">
                <h3 className="float-start" >TODAY DEALS  <button type="button" class=" btn btn-link">see all link</button>  </h3>
              </div>

              <div id="carouselExample2" className="carousel slide">
                <div className="carousel-inner text-center ">
                  <div className="carousel-item active">
                    <div className="imgcont row">
                      <div className="col">1</div>
                      <div className="col">2</div>
                      <div className="col">3</div>
                      <div className="col">4</div>
                      <div className="col">5</div>
                      <div className="col">6</div>

                    </div>
                  </div>
                  <div className="carousel-item">
                    <div className="imgcont row">


                      <div className="col">7</div>
                      <div className="col">8</div>
                      <div className="col">9</div>
                      <div className="col">10</div>
                      <div className="col">11</div>
                      <div className="col">12</div>



                    </div>
                  </div>
                  <div className="carousel-item">
                    <div className="imgcont row">


                      <div className="col">13</div>
                      <div className="col">14</div>
                      <div className="col">15</div>
                      <div className="col">16</div>
                      <div className="col">17</div>
                      <div className="col">18</div>

                    </div>
                  </div>
                </div>
                <button className="a_cc carousel-control-prev rounded-end " type="button" data-bs-target="#carouselExample2" data-bs-slide="prev">
                  <span className="carousel-control-prev-icon" aria-hidden="true"></span>
                  <span className="visually-hidden bg-dark text-dark ">Previous</span>
                </button>
                <button className="a_cc carousel-control-next rounded-start" type="button" data-bs-target="#carouselExample2" data-bs-slide="next">
                  <span className="carousel-control-next-icon" aria-hidden="true"></span>
                  <span className="visually-hidden">Next</span>
                </button>
              </div>

            </div>

          </div>
        </main>

        <footer>         </footer>

      </div>


    )
  }
}


App.propTypes = {}
export default App